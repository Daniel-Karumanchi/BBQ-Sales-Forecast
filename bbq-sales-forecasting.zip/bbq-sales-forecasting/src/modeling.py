"""Build forecasters from a saved configuration and backtest them (Steps 4 + 6)."""
import numpy as np
import pandas as pd
from lightgbm import LGBMRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import FunctionTransformer
from skforecast.recursive import ForecasterRecursive
from skforecast.model_selection import TimeSeriesFold, backtesting_forecaster

from src.config import HORIZON, RANDOM_STATE
from src.features import make_window_features


def make_estimator(model: str, params: dict | None = None):
    params = dict(params or {})
    if model == "LightGBM-Tweedie":
        # Tweedie loss is designed for counts with many zeros and rare large values
        return LGBMRegressor(objective="tweedie", random_state=RANDOM_STATE, verbose=-1, **params)
    if model == "LightGBM":
        return LGBMRegressor(random_state=RANDOM_STATE, verbose=-1, **params)
    if model == "RandomForest":
        return RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, **params)
    raise ValueError(model)


def make_forecaster(model: str, lags, params: dict | None = None, log_target: bool = False):
    return ForecasterRecursive(
        estimator=make_estimator(model, params),
        lags=lags,
        window_features=make_window_features(),
        transformer_y=FunctionTransformer(np.log1p, np.expm1) if log_target else None,
    )


def backtest(forecaster, y: pd.Series, exog: pd.DataFrame | None, start: pd.Timestamp, refit: bool = True):
    """Forecast every 30-day window after `start`, using only data before each window.

    Returns the predictions (negative values clipped to 0, since sales cannot be negative)."""
    cv = TimeSeriesFold(steps=HORIZON, initial_train_size=len(y.loc[:start]), refit=refit, verbose=False)
    _, pred = backtesting_forecaster(
        forecaster, y=y, exog=exog, cv=cv, metric="mean_absolute_error", show_progress=False
    )
    return pred["pred"].clip(lower=0)
