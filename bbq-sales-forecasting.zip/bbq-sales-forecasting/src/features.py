"""Feature engineering shared by all scripts (Step 3).

Two kinds of features:
* Features skforecast builds itself from past sales: lags and rolling windows
  (defined in `make_window_features` and the `LAGS` list).
* Exogenous features we build here, which must also be known for the 30 future days:
  calendar, holidays and climate.
"""
import numpy as np
import pandas as pd
import holidays
from skforecast.preprocessing import RollingFeatures

# Past sales the model looks at: the last 7 days, two weeks ago, and roughly one year ago
LAGS = [1, 2, 3, 4, 5, 6, 7, 14, 21, 28, 364]

CLIMATE_RAW = [
    "mean_temp_nationwide", "min_temp_nationwide", "max_temp_nationwide",
    "mean_precipitation_mm_nationwide", "min_precipitation_mm_nationwide", "max_precipitation_mm_nationwide",
    "mean_sun_hours_nationwide", "min_sun_hours_nationwide", "max_sun_hours_nationwide",
]


def make_window_features():
    """Rolling statistics of past sales (mean and std of the last 7 and 28 days)."""
    return RollingFeatures(stats=["mean", "std", "mean", "std"], window_sizes=[7, 7, 28, 28])


def calendar_features(index: pd.DatetimeIndex) -> pd.DataFrame:
    """Day-of-week dummies + cyclical (sin/cos) month and day-of-year + German holidays."""
    df = pd.DataFrame(index=index)
    dow = index.dayofweek
    for d, name in enumerate(["mon", "tue", "wed", "thu", "fri", "sat", "sun"]):
        df[f"dow_{name}"] = (dow == d).astype(int)
    doy = index.dayofyear
    df["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    df["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    df["month_sin"] = np.sin(2 * np.pi * index.month / 12)
    df["month_cos"] = np.cos(2 * np.pi * index.month / 12)

    years = range(index.year.min() - 1, index.year.max() + 2)
    de_holidays = holidays.Germany(years=years)
    df["is_holiday"] = index.isin(pd.to_datetime(list(de_holidays.keys()))).astype(int)
    # Days just before a holiday (people shop for the BBQ)
    df["pre_holiday"] = pd.Series(df["is_holiday"].values, index=index).shift(-1, fill_value=0).astype(int).values
    # Easter and Ascension Day (= Father's Day in Germany): big BBQ occasions
    special = [d for d, n in de_holidays.items() if n in ("Ostermontag", "Christi Himmelfahrt", "Easter Monday", "Ascension Day")]
    special = pd.to_datetime(special)
    days_to = np.array([min([(s - t).days for s in special if (s - t).days >= 0] or [365]) for t in index])
    df["days_to_bbq_holiday"] = np.clip(days_to, 0, 30)
    return df


def climate_features(climate: pd.DataFrame) -> pd.DataFrame:
    """Raw climate columns + 7-day rolling means of temperature, rain and sunshine."""
    df = climate[CLIMATE_RAW].copy()
    for col in ["mean_temp_nationwide", "mean_precipitation_mm_nationwide", "mean_sun_hours_nationwide"]:
        df[f"{col}_roll7"] = df[col].rolling(7, min_periods=1).mean()
    return df


def climate_normals(climate: pd.DataFrame, future_index: pd.DatetimeIndex) -> pd.DataFrame:
    """Future weather is unknown, so use the historical average for each calendar day
    (smoothed over +-7 days). This is the honest 'climatology' scenario."""
    hist = climate[CLIMATE_RAW].copy()
    doy_mean = hist.groupby(hist.index.dayofyear).mean()
    doy_mean = doy_mean.reindex(range(1, 367)).interpolate().bfill().ffill()
    smooth = pd.concat([doy_mean.iloc[-7:], doy_mean, doy_mean.iloc[:7]]).rolling(15, center=True).mean().iloc[7:-7]
    smooth.index = range(1, 367)
    future = smooth.loc[future_index.dayofyear].set_index(future_index)
    # Rolling means need recent history to start from
    full = pd.concat([hist, future])
    return climate_features(full).loc[future_index]


def build_exog(daily: pd.DataFrame, use_climate: bool = True) -> pd.DataFrame:
    cal = calendar_features(daily.index)
    if not use_climate:
        return cal
    return pd.concat([cal, climate_features(daily)], axis=1)


def build_future_exog(daily: pd.DataFrame, horizon: int, use_climate: bool = True) -> pd.DataFrame:
    future_index = pd.date_range(daily.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    cal = calendar_features(future_index)
    if not use_climate:
        return cal
    return pd.concat([cal, climate_normals(daily, future_index)], axis=1)
