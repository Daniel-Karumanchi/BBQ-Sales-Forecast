"""Shared settings for all scripts. Change values here, not inside the scripts."""
from pathlib import Path

# Project root = the folder that contains this "src" folder
ROOT = Path(__file__).resolve().parents[1]

RAW_SALES = ROOT / "data" / "raw" / "bbq_sauce_sales.csv"
RAW_CLIMATE = ROOT / "data" / "raw" / "climate_data_2026.csv"
PROCESSED = ROOT / "data" / "processed" / "daily.csv"
OUTPUTS = ROOT / "outputs"
FIGURES = OUTPUTS / "figures"
BEST_PARAMS = OUTPUTS / "best_params.json"
SELECTED_FEATURES = OUTPUTS / "selected_features.json"

HORIZON = 30            # forecast 30 days ahead (slide 26)
TEST_DAYS = 180         # last 180 days = 6 test windows of 30 days, never used for tuning
VALIDATION_DAYS = 180   # 180 days before the test set, used for hyperparameter tuning
RANDOM_STATE = 42

for folder in (OUTPUTS, FIGURES, PROCESSED.parent):
    folder.mkdir(parents=True, exist_ok=True)
