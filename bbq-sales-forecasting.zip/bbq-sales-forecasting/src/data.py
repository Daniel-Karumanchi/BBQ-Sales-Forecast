"""Load the processed daily dataset and split it in time order (Step 2)."""
import pandas as pd
from src.config import PROCESSED, TEST_DAYS, VALIDATION_DAYS


def load_daily() -> pd.DataFrame:
    df = pd.read_csv(PROCESSED, parse_dates=["date"], index_col="date")
    return df.asfreq("D")


def split_dates(index: pd.DatetimeIndex):
    """Return (end_train, end_validation): train <= end_train < validation <= end_validation < test."""
    end_validation = index[-TEST_DAYS - 1]
    end_train = index[-TEST_DAYS - VALIDATION_DAYS - 1]
    return end_train, end_validation
