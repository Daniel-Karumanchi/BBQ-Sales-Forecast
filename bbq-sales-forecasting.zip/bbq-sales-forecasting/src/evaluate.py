"""Error metrics and baselines shared by all scripts (Step 6)."""
import numpy as np
import pandas as pd
from src.config import HORIZON


def metrics(actual: pd.Series, pred: pd.Series) -> dict:
    """MAE / RMSE in bottles per day, WAPE in % of sales, and the error of the 30-day TOTAL.

    MAPE is not used: it divides by actual sales, which are 0 on many days.
    """
    actual, pred = actual.align(pred, join="inner")
    err = actual - pred
    # Sum actual and predicted sales over each consecutive 30-day window of the test period
    window = np.arange(len(actual)) // HORIZON
    totals = pd.DataFrame({"a": actual.values, "p": pred.values, "w": window}).groupby("w").sum()
    return {
        "MAE": err.abs().mean(),
        "RMSE": np.sqrt((err ** 2).mean()),
        "WAPE": err.abs().sum() / actual.sum(),
        "30d_total_error_%": ((totals.a - totals.p).abs() / totals.a).mean(),
    }


def baseline_predictions(y: pd.Series, test_index: pd.DatetimeIndex) -> dict:
    """Simple forecasts every model must beat. Each test window of 30 days only uses data
    available BEFORE that window starts (same rules as the real models)."""
    preds = {"Seasonal naive (same weekday last year)": y.shift(364).loc[test_index]}
    weekday_mean = []
    for start in range(0, len(test_index), HORIZON):
        idx = test_index[start:start + HORIZON]
        history = y.loc[: idx[0] - pd.Timedelta(days=1)].iloc[-56:]  # last 8 weeks
        means = history.groupby(history.index.dayofweek).mean()
        weekday_mean.append(pd.Series(means.reindex(idx.dayofweek).values, index=idx))
    preds["Weekday average of last 8 weeks"] = pd.concat(weekday_mean)
    return preds


def forecast_score(y_true, y_pred) -> float:
    """Tuning metric used in script 02 (lower = better).

    = WAPE (daily accuracy) + average error of the 30-day totals (volume accuracy).
    Daily MAE alone rewards models that predict the quiet 'typical' day and miss the big
    orders, which badly under-forecasts the 30-day amount the project asks for.
    """
    y_true, y_pred = np.asarray(y_true, float), np.clip(np.asarray(y_pred, float), 0, None)
    wape = np.abs(y_true - y_pred).sum() / y_true.sum()
    n = len(y_true) // HORIZON * HORIZON
    if n == 0:
        return wape
    t_true = y_true[:n].reshape(-1, HORIZON).sum(axis=1)
    t_pred = y_pred[:n].reshape(-1, HORIZON).sum(axis=1)
    return wape + np.mean(np.abs(t_true - t_pred) / np.maximum(t_true, 1))
