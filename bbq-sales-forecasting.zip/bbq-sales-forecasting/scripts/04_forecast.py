# %% [markdown]
# # 04 – Final 30-day forecast  (Step 7)
# Retrain the chosen model on ALL data and forecast the next 30 days, with an 80% prediction
# interval. Future weather is unknown, so the historical average for each calendar day is used.
# Output: outputs/forecast_30_days.csv + outputs/forecast_summary.json (used by the dashboard)

# %% Setup
import sys, json, warnings
from pathlib import Path
ROOT = Path.cwd() if (Path.cwd() / "src").exists() else Path.cwd().parent
sys.path.insert(0, str(ROOT))
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from src.config import HORIZON, BEST_PARAMS, SELECTED_FEATURES, OUTPUTS, FIGURES
from src.data import load_daily, split_dates
from src.features import build_exog, build_future_exog
from src.modeling import make_forecaster, backtest

# %% Load data, tuned model (02) and chosen features (03)
daily = load_daily()
y = daily["amount"]
best = json.loads(BEST_PARAMS.read_text())
model = best["winner"]
lags, params = best[model]["lags"], best[model]["params"]
cols = json.loads(SELECTED_FEATURES.read_text())["features"]
uses_climate = any("nationwide" in c for c in cols)

exog = build_exog(daily, use_climate=True)[cols]
future_exog = build_future_exog(daily, HORIZON, use_climate=True)[cols]
print(f"Model: {model} | lags: {lags} | {len(cols)} features | climate used: {uses_climate}")
print("Forecast period:", future_exog.index[0].date(), "->", future_exog.index[-1].date())

# %% Realistic uncertainty: use the errors the model made on the TEST period (out-of-sample)
_, end_validation = split_dates(daily.index)
test_pred = backtest(make_forecaster(model, lags, params), y, exog, end_validation, refit=True)

# %% Retrain on ALL data and forecast 30 days
forecaster = make_forecaster(model, lags, params)
forecaster.fit(y=y, exog=exog)
forecaster.set_out_sample_residuals(y_true=y.loc[test_pred.index], y_pred=test_pred)

point = forecaster.predict(steps=HORIZON, exog=future_exog).clip(lower=0)
# 500 simulated future paths -> daily ranges AND a range for the 30-day total
paths = forecaster.predict_bootstrapping(
    steps=HORIZON, exog=future_exog, n_boot=500, use_in_sample_residuals=False
).clip(lower=0)
forecast = pd.DataFrame({
    "pred": point,
    "lower_80": paths.quantile(0.10, axis=1),
    "upper_80": paths.quantile(0.90, axis=1),
})
forecast.index.name = "date"
forecast.round(0)

# %% The 30-day total (the number a business plans stock with)
path_totals = paths.sum(axis=0)
last_30 = y.iloc[-HORIZON:].sum()
same_period_last_year = y.loc[future_exog.index - pd.Timedelta(days=364)].sum()
summary = {
    "model": model,
    "climate_used": uses_climate,
    "forecast_start": str(future_exog.index[0].date()),
    "forecast_end": str(future_exog.index[-1].date()),
    "total_30d_forecast": float(point.sum()),
    "total_30d_lower_80": float(np.quantile(path_totals, 0.10)),
    "total_30d_upper_80": float(np.quantile(path_totals, 0.90)),
    "last_30d_actual": float(last_30),
    "same_period_last_year_actual": float(same_period_last_year),
}
for k, v in summary.items():
    print(f"{k:32s} {v:,.0f}" if isinstance(v, float) else f"{k:32s} {v}")

# %% Plot: last 120 days of history + 30-day forecast
plt.figure(figsize=(12, 4.5))
plt.plot(y.iloc[-120:], color="#555", lw=0.8, label="Actual (last 120 days)")
plt.plot(forecast.pred, color="#c0392b", lw=2, label="Forecast")
plt.fill_between(forecast.index, forecast.lower_80, forecast.upper_80, color="#c0392b", alpha=0.15, label="80% interval")
plt.title(f"BBQ sauce – 30-day forecast: {point.sum():,.0f} bottles "
          f"(80% range {summary['total_30d_lower_80']:,.0f}–{summary['total_30d_upper_80']:,.0f})")
plt.ylabel("Bottles per day"); plt.legend()
plt.savefig(FIGURES / "04_forecast.png", dpi=120); plt.show()

# %% What-if: how much would a sunnier, warmer month change the forecast?
if uses_climate:
    scenario = future_exog.copy()
    sun = [c for c in cols if "sun_hours" in c]
    temp = [c for c in cols if "temp" in c]
    scenario[sun] = scenario[sun] * 1.3
    scenario[temp] = scenario[temp] + 2
    p_sunny = forecaster.predict(steps=HORIZON, exog=scenario).clip(lower=0).sum()
    summary["whatif_sunny_warm_total"] = float(p_sunny)
    print(f"Base: {point.sum():,.0f} | +30% sunshine & +2 °C: {p_sunny:,.0f} ({p_sunny / point.sum() - 1:+.1%})")

# %% Save for the dashboard and the report
forecast.round(1).to_csv(OUTPUTS / "forecast_30_days.csv")
(OUTPUTS / "forecast_summary.json").write_text(json.dumps(summary, indent=2))
print("Saved:", OUTPUTS / "forecast_30_days.csv")
