# %% [markdown]
# # 02 – Baselines, models and hyperparameter tuning  (Steps 3 + 4)
# Tuning uses ONLY train + validation data. The test period stays hidden until script 03.
# Runtime: about 2–4 minutes.

# %% Setup
import sys, json, warnings
from pathlib import Path
ROOT = Path.cwd() if (Path.cwd() / "src").exists() else Path.cwd().parent
sys.path.insert(0, str(ROOT))
warnings.filterwarnings("ignore")

import pandas as pd
import matplotlib.pyplot as plt
from skforecast.model_selection import TimeSeriesFold, grid_search_forecaster

from src.config import HORIZON, BEST_PARAMS, OUTPUTS, FIGURES
from src.data import load_daily, split_dates
from src.features import LAGS, build_exog
from src.evaluate import metrics, baseline_predictions, forecast_score
from src.modeling import make_forecaster, backtest

# %% Load data and build features (Step 3: the feature code lives in src/features.py)
daily = load_daily()
y = daily["amount"]
exog = build_exog(daily, use_climate=True)
end_train, end_validation = split_dates(daily.index)
print(exog.shape[1], "exogenous features:", list(exog.columns))

# Tuning works on train + validation only
y_tv, exog_tv = y.loc[:end_validation], exog.loc[:end_validation]
validation_index = y.loc[end_train:end_validation].index[1:]

# %% Baselines on the validation period: every model must beat these
rows = []
for name, pred in baseline_predictions(y, validation_index).items():
    rows.append({"model": name, **metrics(y.loc[validation_index], pred)})
pd.DataFrame(rows).round(3)

# %% Cross-validation for tuning: train up to end_train, then forecast 6 windows of 30 days
cv = TimeSeriesFold(steps=HORIZON, initial_train_size=len(y.loc[:end_train]), refit=False, verbose=False)

lags_grid = {
    "last week": [1, 2, 3, 4, 5, 6, 7],
    "last 4 weeks": [1, 2, 3, 4, 5, 6, 7, 14, 21, 28],
    "4 weeks + last year": LAGS,
}
param_grids = {
    "LightGBM-Tweedie": {
        "n_estimators": [200, 500],
        "learning_rate": [0.02, 0.05],
        "max_depth": [3, 5],
        "min_child_samples": [20, 50],
        "tweedie_variance_power": [1.2, 1.5],
    },
    "RandomForest": {
        "n_estimators": [300],
        "max_depth": [5, 10],
        "min_samples_leaf": [5, 20],
    },
}

# %% Grid search: try every combination of lags x hyperparameters (Step 4)
search_results, best = {}, {}
for model, grid in param_grids.items():
    print(f"\nTuning {model} ...")
    res = grid_search_forecaster(
        make_forecaster(model, lags=7), y=y_tv, exog=exog_tv, cv=cv,
        param_grid=grid, lags_grid=lags_grid, metric=forecast_score,
        return_best=False, show_progress=True,
    )
    search_results[model] = res
    top = res.iloc[0]
    best[model] = {
        "lags": [int(l) for l in top["lags"]],
        "lags_label": top["lags_label"],
        "params": {k: (int(v) if isinstance(v, float) and v.is_integer() else v) for k, v in top["params"].items()},
    }
    print(res[["lags_label", "params", "forecast_score"]].head(5).to_string())

# %% Full metrics for each tuned model on the validation period
# Tuning metric = forecast_score (src/evaluate.py): WAPE + error of the 30-day totals.
# It balances daily accuracy with getting the 30-day AMOUNT right (what slide 26 asks for).
for model, cfg in best.items():
    pred = backtest(make_forecaster(model, cfg["lags"], cfg["params"]), y_tv, exog_tv, end_train, refit=False)
    m = metrics(y.loc[validation_index], pred)
    best[model]["validation"] = m
    rows.append({"model": f"{model} (tuned)", **m})

# A common trap: log-transforming the target lowers the daily MAE but predicts the MEDIAN day,
# so the 30-day TOTAL is heavily under-forecast. Shown here for the presentation.
cfg = best["LightGBM-Tweedie"]
trap = make_forecaster("LightGBM", cfg["lags"], {k: v for k, v in cfg["params"].items() if k != "tweedie_variance_power"}, log_target=True)
rows.append({"model": "LightGBM + log target (trap)", **metrics(y.loc[validation_index], backtest(trap, y_tv, exog_tv, end_train, refit=False))})

comparison = pd.DataFrame(rows)
comparison["score (WAPE + 30d error)"] = comparison["WAPE"] + comparison["30d_total_error_%"]
comparison = comparison.sort_values("score (WAPE + 30d error)").reset_index(drop=True)
comparison.to_csv(OUTPUTS / "02_validation_comparison.csv", index=False)
print(comparison.round(3).to_string())

# %% Plot: tuned models vs actual on the validation period
plt.figure(figsize=(12, 4))
plt.plot(validation_index, y.loc[validation_index], color="#999", lw=0.8, label="Actual")
for model, cfg in best.items():
    pred = backtest(make_forecaster(model, cfg["lags"], cfg["params"]), y_tv, exog_tv, end_train, refit=False)
    plt.plot(pred.index, pred, lw=1.5, label=model)
plt.title("Validation period: tuned models vs actual (daily bottles)"); plt.legend()
plt.savefig(FIGURES / "02_validation_predictions.png", dpi=120); plt.show()

# %% Save the winner (lowest validation forecast_score = WAPE + 30-day total error) for scripts 03 and 04
score = lambda m: m["WAPE"] + m["30d_total_error_%"]
winner = min(best, key=lambda k: score(best[k]["validation"]))
best["winner"] = winner
BEST_PARAMS.write_text(json.dumps(best, indent=2, default=float))
print("Best model:", winner, best[winner]["lags_label"], best[winner]["params"])
print("Saved:", BEST_PARAMS)
