# %% [markdown]
# # 03 – Feature selection (incl. climate) and model validation  (Steps 5 + 6)
# 1. Feature selection with RFECV on train + validation data
# 2. Climate test: the same tuned model WITHOUT climate / WITH all climate / WITH selected features
# 3. Decide on the VALIDATION period, then report the honest result on the hidden TEST period
# 4. Explain the model with SHAP values
# Runtime: about 2–4 minutes.

# %% Setup
import sys, json, warnings
from pathlib import Path
ROOT = Path.cwd() if (Path.cwd() / "src").exists() else Path.cwd().parent
sys.path.insert(0, str(ROOT))
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
from scipy.stats import wilcoxon
from sklearn.feature_selection import RFECV
from sklearn.model_selection import TimeSeriesSplit
from skforecast.feature_selection import select_features

from src.config import BEST_PARAMS, SELECTED_FEATURES, OUTPUTS, FIGURES
from src.data import load_daily, split_dates
from src.features import build_exog, CLIMATE_RAW
from src.evaluate import metrics, baseline_predictions
from src.modeling import make_forecaster, make_estimator, backtest

# %% Load data, features and the tuned model from script 02
daily = load_daily()
y = daily["amount"]
exog_all = build_exog(daily, use_climate=True)
calendar_cols = list(build_exog(daily, use_climate=False).columns)
climate_cols = [c for c in exog_all.columns if c not in calendar_cols]
end_train, end_validation = split_dates(daily.index)
validation_index = y.loc[end_train:end_validation].index[1:]
test_index = y.loc[end_validation:].index[1:]

best = json.loads(BEST_PARAMS.read_text())
model = best["winner"]
lags, params = best[model]["lags"], best[model]["params"]
print("Tuned model from script 02:", model, lags, params)

# %% Step 5 – Feature selection with RFECV (Recursive Feature Elimination with Cross-Validation)
# RFECV repeatedly drops the least important feature and keeps the set with the best CV error.
# Only exogenous features (calendar + climate) are selected; lags were already tuned in 02.
selector = RFECV(
    estimator=make_estimator(model, params),
    step=1,
    cv=TimeSeriesSplit(n_splits=3),          # time-ordered folds, no shuffling
    scoring="neg_mean_absolute_error",
    min_features_to_select=5,
)
_, _, selected_exog, _ = select_features(
    forecaster=make_forecaster(model, lags, params),
    selector=selector,
    y=y.loc[:end_validation],
    exog=exog_all.loc[:end_validation],
    select_only="exog",
    subsample=1.0,
    verbose=False,
)
dropped = [c for c in exog_all.columns if c not in selected_exog]
print(f"Selected {len(selected_exog)} of {exog_all.shape[1]} exogenous features")
print("Kept climate features:   ", [c for c in selected_exog if c in climate_cols])
print("Dropped features:        ", dropped)

# %% Step 6 – Compare feature sets. Decide on VALIDATION, report on TEST.
variants = {
    "calendar only (no climate)": calendar_cols,
    "calendar + all climate": list(exog_all.columns),
    "RFECV-selected features": selected_exog,
}


def evaluate(index, start, y_upto):
    rows, preds = [], {}
    for name, pred in baseline_predictions(y, index).items():
        rows.append({"model": f"Baseline: {name}", **metrics(y.loc[index], pred)}); preds[name] = pred
    for name, cols in variants.items():
        pred = backtest(make_forecaster(model, lags, params), y_upto, exog_all.loc[y_upto.index, cols], start, refit=True)
        rows.append({"model": f"{model}: {name}", **metrics(y.loc[index], pred)}); preds[name] = pred
    table = pd.DataFrame(rows)
    table["score (WAPE + 30d error)"] = table["WAPE"] + table["30d_total_error_%"]
    return table.sort_values("score (WAPE + 30d error)").reset_index(drop=True), preds


val_table, _ = evaluate(validation_index, end_train, y.loc[:end_validation])
print("VALIDATION period (used to decide):")
print(val_table.round(3).to_string())

# %% Pick the feature set with the best validation score
model_rows = val_table[val_table.model.str.startswith(model)]
chosen_name = model_rows.iloc[0].model.split(": ", 1)[1]
chosen_cols = variants[chosen_name]
print("Chosen feature set:", chosen_name, f"({len(chosen_cols)} features)")

# %% Final honest check on the TEST period (data the model never saw during tuning/selection)
test_table, test_preds = evaluate(test_index, end_validation, y)
print("TEST period (final result):")
print(test_table.round(3).to_string())
test_table.to_csv(OUTPUTS / "03_test_comparison.csv", index=False)

# %% Is the effect of climate statistically significant? (paired test on daily absolute errors)
err_no = (y.loc[test_index] - test_preds["calendar only (no climate)"]).abs()
err_cl = (y.loc[test_index] - test_preds["calendar + all climate"]).abs()
p_value = wilcoxon(err_no, err_cl).pvalue
print(f"Test MAE without climate: {err_no.mean():.0f} | with climate: {err_cl.mean():.0f} | Wilcoxon p = {p_value:.3f}")
print("p < 0.05 would mean the difference is unlikely to be chance.")

# %% Plot: test period, actual vs predictions (daily and as 30-day totals)
fig, ax = plt.subplots(2, 1, figsize=(12, 8))
ax[0].plot(test_index, y.loc[test_index], color="#999", lw=0.8, label="Actual")
ax[0].plot(test_preds[chosen_name], color="#c0392b", lw=1.5, label=f"{model} ({chosen_name})")
ax[0].plot(test_preds["Weekday average of last 8 weeks"], color="k", ls="--", lw=1, label="Baseline: weekday average")
ax[0].set_title("Test period – daily bottles"); ax[0].legend()
win = np.arange(len(test_index)) // 30
totals = pd.DataFrame({"Actual": y.loc[test_index].values,
                       "Model": test_preds[chosen_name].values,
                       "Baseline": test_preds["Weekday average of last 8 weeks"].values}).groupby(win).sum()
totals.index = [test_index[i * 30].strftime("%d %b %Y") for i in totals.index]
totals.plot.bar(ax=ax[1], color=["#999", "#c0392b", "#333"], rot=0)
ax[1].set_title("Test period – 30-day totals (window start date)")
plt.tight_layout(); plt.savefig(FIGURES / "03_test_predictions.png", dpi=120); plt.show()

# %% Explainability: SHAP values of the model trained on train + validation
forecaster = make_forecaster(model, lags, params)
forecaster.fit(y=y.loc[:end_validation], exog=exog_all.loc[:end_validation, chosen_cols])
X_train, _ = forecaster.create_train_X_y(y=y.loc[:end_validation], exog=exog_all.loc[:end_validation, chosen_cols])
explainer = shap.TreeExplainer(forecaster.estimator)
shap_values = explainer.shap_values(X_train)

shap.summary_plot(shap_values, X_train, max_display=20, show=False)
plt.title("SHAP: what pushes the daily forecast up (right) or down (left)")
plt.tight_layout(); plt.savefig(FIGURES / "03_shap_summary.png", dpi=120); plt.show()

importance = pd.Series(np.abs(shap_values).mean(axis=0), index=X_train.columns).sort_values(ascending=False)
group = importance.groupby(lambda c: "climate" if c in climate_cols else ("lags / rolling" if c.startswith(("lag", "roll")) else "calendar")).sum()
print("Share of total SHAP importance by feature group:\n", (group / group.sum()).round(3))
importance.to_csv(OUTPUTS / "03_shap_importance.csv", header=["mean_abs_shap"])

# %% Save the chosen feature set for script 04
SELECTED_FEATURES.write_text(json.dumps({
    "chosen_variant": chosen_name, "features": chosen_cols,
    "rfecv_selected": selected_exog, "wilcoxon_p_climate": float(p_value),
}, indent=2))
print("Saved:", SELECTED_FEATURES)
