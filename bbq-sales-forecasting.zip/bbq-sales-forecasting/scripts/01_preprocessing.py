# %% [markdown]
# # 01 – Pre-processing, exploration and train-test split  (Steps 1 + 2)
# Run cell by cell in Positron (Ctrl/Cmd + Enter), or the whole file with "Run Python File".
# Positron must have the project folder (bbq-sales-forecasting) open as the workspace.

# %% Setup
import sys
from pathlib import Path
ROOT = Path.cwd() if (Path.cwd() / "src").exists() else Path.cwd().parent
sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from src.config import RAW_SALES, RAW_CLIMATE, PROCESSED, FIGURES, TEST_DAYS, VALIDATION_DAYS
from src.data import split_dates

plt.rcParams.update({"figure.figsize": (12, 4), "axes.spines.top": False, "axes.spines.right": False})

# %% 1. Load both files and join them on the date
sales = pd.read_csv(RAW_SALES, parse_dates=["date"])
climate = pd.read_csv(RAW_CLIMATE, parse_dates=["date"])
print("Sales:", sales.shape, "| Climate:", climate.shape)
print("Duplicate dates:", sales.date.duplicated().sum(), climate.date.duplicated().sum())
print("Missing values:\n", sales.isna().sum().to_dict(), climate.isna().sum().sum())

# Data-quality issue: the climate file has 2025-02-28 twice, with different values.
# We cannot tell which one is right, so we take the average of the two rows.
print(climate[climate.date.duplicated(keep=False)])
climate = climate.groupby("date", as_index=False).mean()

df = sales.merge(climate, on="date", how="outer").set_index("date").sort_index()
print("Period:", df.index.min().date(), "->", df.index.max().date())

# %% 2. Make the series continuous: one row per calendar day
# Days without a record (mostly Sundays/Mondays and public holidays) = no sales -> 0
df["recorded"] = df["amount"].notna().astype(int)
daily = df.asfreq("D")
daily["recorded"] = daily["recorded"].fillna(0).astype(int)
daily["amount"] = daily["amount"].fillna(0)
climate_cols = [c for c in climate.columns if c != "date"]
daily[climate_cols] = daily[climate_cols].interpolate(limit_direction="both")
print(f"{len(daily)} calendar days, {(daily.recorded == 0).sum()} days without a record filled with 0")

# %% 3. Explore: how do sales look?
print(daily["amount"].describe().round(1))
fig, ax = plt.subplots(2, 1, figsize=(12, 7), sharex=True)
ax[0].plot(daily.index, daily.amount, lw=0.5, color="#555")
ax[0].set_title("Daily bottles sold")
weekly = daily.amount.resample("W").sum()
ax[1].plot(weekly.index, weekly, color="#c0392b")
ax[1].plot(weekly.rolling(8, center=True).mean(), color="k", lw=2, label="8-week average")
ax[1].set_title("Weekly bottles sold"); ax[1].legend()
plt.tight_layout(); plt.savefig(FIGURES / "01_sales_over_time.png", dpi=120); plt.show()

# %% 4. Seasonality: by month and by weekday
fig, ax = plt.subplots(1, 2, figsize=(13, 4))
monthly = daily.amount.resample("ME").sum()
monthly.groupby(monthly.index.month).mean().plot.bar(ax=ax[0], color="#c0392b")
ax[0].set_title("Average bottles per calendar month"); ax[0].set_xlabel("Month")
daily.groupby(daily.index.dayofweek).amount.mean().rename(
    index=dict(enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]))).plot.bar(ax=ax[1], color="#555")
ax[1].set_title("Average bottles per weekday"); ax[1].set_xlabel("")
plt.tight_layout(); plt.savefig(FIGURES / "01_seasonality.png", dpi=120); plt.show()

# %% 5. Outliers: a few very large orders
q99 = daily.amount.quantile(0.99)
print(f"99th percentile: {q99:.0f} bottles/day; days above it: {(daily.amount > q99).sum()}")
print("Share of all bottles sold on the top 10% of days:",
      f"{daily.amount.nlargest(int(len(daily) * 0.1)).sum() / daily.amount.sum():.0%}")
# Decision: we KEEP the large orders (they are real sales). The models are tree-based,
# which are robust to outliers, and we report MAE (not squared error) as the main metric.

# %% 6. Does the weather relate to sales? (Spearman correlation, daily vs weekly)
weekly_df = daily.resample("W").agg({"amount": "sum", **{c: "mean" for c in climate_cols}})
corr = pd.DataFrame({
    "daily": daily[["amount"] + climate_cols].corr(method="spearman")["amount"],
    "weekly": weekly_df.corr(method="spearman")["amount"],
}).drop("amount").round(3)
print(corr)

# %% 7. Train / validation / test split (time order, never shuffled)
end_train, end_validation = split_dates(daily.index)
print(f"Train:      {daily.index[0].date()} -> {end_train.date()}  ({len(daily.loc[:end_train])} days)")
print(f"Validation: {daily.loc[end_train:].index[1].date()} -> {end_validation.date()}  ({VALIDATION_DAYS} days, used for tuning)")
print(f"Test:       {daily.loc[end_validation:].index[1].date()} -> {daily.index[-1].date()}  ({TEST_DAYS} days, used once at the end)")

fig, ax = plt.subplots()
ax.plot(daily.amount.loc[:end_train], lw=0.5, label="train")
ax.plot(daily.amount.loc[end_train:end_validation], lw=0.5, label="validation")
ax.plot(daily.amount.loc[end_validation:], lw=0.5, label="test")
ax.set_title("Train / validation / test split"); ax.legend()
plt.savefig(FIGURES / "01_split.png", dpi=120); plt.show()

# %% 8. Save the clean dataset for the next scripts
daily.reset_index().to_csv(PROCESSED, index=False)
print("Saved:", PROCESSED)
