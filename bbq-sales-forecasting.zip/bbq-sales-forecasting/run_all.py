"""Run the whole pipeline in order: python run_all.py   (takes about 2–5 minutes)."""
import os
import runpy
import time
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")   # save charts to outputs/figures without opening windows
ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

for script in ["01_preprocessing.py", "02_modelling_tuning.py", "03_selection_validation.py", "04_forecast.py"]:
    print(f"\n{'=' * 70}\nRunning {script}\n{'=' * 70}")
    t = time.time()
    runpy.run_path(str(ROOT / "scripts" / script), run_name="__main__")
    print(f"--> {script} finished in {time.time() - t:.0f} s")

print("\nDone. Results are in outputs/ . Start the dashboard with:  streamlit run dashboard/app.py")
