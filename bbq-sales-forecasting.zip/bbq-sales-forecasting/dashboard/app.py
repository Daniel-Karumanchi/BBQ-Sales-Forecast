"""Bonus dashboard. Run from the project folder:   streamlit run dashboard/app.py
(In Positron: open this file and press the "Run App" button.)
Run scripts 01–04 first: the dashboard only reads their saved outputs."""
import json
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"

st.set_page_config(page_title="BBQ Sauce Sales Forecast", layout="wide")


@st.cache_data
def load():
    daily = pd.read_csv(ROOT / "data" / "processed" / "daily.csv", parse_dates=["date"], index_col="date")
    fc = pd.read_csv(OUT / "forecast_30_days.csv", parse_dates=["date"], index_col="date")
    summary = json.loads((OUT / "forecast_summary.json").read_text())
    test = pd.read_csv(OUT / "03_test_comparison.csv")
    shap_imp = pd.read_csv(OUT / "03_shap_importance.csv", index_col=0)
    selection = json.loads((OUT / "selected_features.json").read_text())
    return daily, fc, summary, test, shap_imp, selection


daily, fc, summary, test, shap_imp, selection = load()

st.title("BBQ Sauce Sales – 30-Day Forecast")
st.caption(f"Model: {summary['model']} · forecast {summary['forecast_start']} to {summary['forecast_end']} · "
           "Digital Transformation group project")

# --- KPI tiles -----------------------------------------------------------------------------
c1, c2, c3, c4 = st.columns(4)
c1.metric("Forecast, next 30 days", f"{summary['total_30d_forecast']:,.0f} bottles",
          f"{summary['total_30d_forecast'] / summary['last_30d_actual'] - 1:+.0%} vs last 30 days")
c2.metric("80% range", f"{summary['total_30d_lower_80']:,.0f} – {summary['total_30d_upper_80']:,.0f}")
c3.metric("Last 30 days (actual)", f"{summary['last_30d_actual']:,.0f}")
c4.metric("Same period last year", f"{summary['same_period_last_year_actual']:,.0f}")

# --- History + forecast chart ----------------------------------------------------------------
st.subheader("History and forecast")
days = st.slider("Days of history to show", 30, 730, 180, step=30)
hist = daily["amount"].iloc[-days:]
view = st.radio("Show", ["Daily", "Weekly totals"], horizontal=True)
fig = go.Figure()
if view == "Daily":
    fig.add_trace(go.Scatter(x=fc.index.tolist() + fc.index[::-1].tolist(),
                             y=fc.upper_80.tolist() + fc.lower_80[::-1].tolist(),
                             fill="toself", fillcolor="rgba(192,57,43,0.15)", line=dict(width=0),
                             name="80% interval", hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=hist.index, y=hist, name="Actual", line=dict(color="#666", width=1)))
    fig.add_trace(go.Scatter(x=fc.index, y=fc.pred, name="Forecast", line=dict(color="#c0392b", width=3)))
else:
    hw = hist.resample("W").sum()
    fw = fc.pred.resample("W").sum()
    fig.add_trace(go.Bar(x=hw.index, y=hw, name="Actual", marker_color="#888"))
    fig.add_trace(go.Bar(x=fw.index, y=fw, name="Forecast", marker_color="#c0392b"))
fig.update_layout(height=420, yaxis_title="Bottles", margin=dict(t=10), legend=dict(orientation="h"))
st.plotly_chart(fig, width="stretch")

# --- Model comparison ------------------------------------------------------------------------
left, right = st.columns(2)
with left:
    st.subheader("Model validation (hidden test period, 180 days)")
    show = test[["model", "MAE", "WAPE", "30d_total_error_%"]].copy()
    show.columns = ["Model", "MAE (bottles/day)", "WAPE", "30-day total error"]
    st.dataframe(show.style.format({"MAE (bottles/day)": "{:.0f}", "WAPE": "{:.0%}", "30-day total error": "{:.0%}"}),
                 hide_index=True, width="stretch")
    st.caption(f"Climate on vs off: Wilcoxon p = {selection['wilcoxon_p_climate']:.2f} "
               "(p ≥ 0.05 → no significant difference).")

with right:
    st.subheader("What drives the forecast? (SHAP)")
    climate_words = ("temp", "precipitation", "sun_hours")
    top = shap_imp.iloc[:15].reset_index()
    top.columns = ["feature", "importance"]
    top["group"] = top.feature.apply(lambda f: "climate" if any(w in f for w in climate_words)
                                     else ("past sales" if f.startswith(("lag", "roll")) else "calendar"))
    bar = px.bar(top[::-1], x="importance", y="feature", color="group", orientation="h",
                 color_discrete_map={"climate": "#c0392b", "past sales": "#555", "calendar": "#999"})
    bar.update_layout(height=420, margin=dict(t=10), xaxis_title="mean |SHAP|", yaxis_title="")
    st.plotly_chart(bar, width="stretch")

# --- Seasonality ------------------------------------------------------------------------------
st.subheader("Seasonality: average bottles per month")
monthly = daily["amount"].resample("ME").sum()
by_month = monthly.groupby(monthly.index.month).mean()
by_month.index = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
st.bar_chart(by_month, color="#c0392b")

with st.expander("Daily forecast table"):
    st.dataframe(fc.round(0), width="stretch")
    st.download_button("Download CSV", fc.round(1).to_csv(), "forecast_30_days.csv")
