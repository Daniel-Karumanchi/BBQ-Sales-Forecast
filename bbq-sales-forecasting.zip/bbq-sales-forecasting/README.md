# BBQ Sauce Sales – 30-Day Forecasting with Machine Learning

Digital Transformation group project (Project 4). We forecast the next 30 days of BBQ sauce sales
with **skforecast**, and test whether German weather data (DWD) improves the forecast.

## How to run it in Positron

1. **Open the folder:** Positron → File → Open Folder → select `bbq-sales-forecasting`.
2. **Pick a Python interpreter** (top right of Positron) with Python 3.12 or newer.
   Recommended: Command Palette (Ctrl/Cmd+Shift+P) → *Python: Create Environment* → venv → tick `requirements.txt`.
3. **Install the libraries** (skip if step 2 did it). In the Positron terminal:
   ```bash
   pip install -r requirements.txt
   ```
4. **Run the analysis.** Either
   - open `run_all.py` and click ▶ *Run Python File* (whole pipeline, ~1–5 min), or
   - open the scripts in `scripts/` **in order** and run them cell by cell with **Ctrl/Cmd+Enter**.
     Each `# %%` line starts a cell; plots appear in the Plots pane, data in the Variables pane.
5. **Dashboard (bonus):** open `dashboard/app.py` and click ▶ *Run App* in Positron, or in the terminal:
   ```bash
   streamlit run dashboard/app.py
   ```

## Project structure

| Path | Workflow step (slide 26) | Team role |
| --- | --- | --- |
| `scripts/01_preprocessing.py` | 1 Pre-processing, 2 Train-test split | Role 2 – Data |
| `src/features.py` | 3 Feature engineering | Role 3 – Features |
| `scripts/02_modelling_tuning.py` | 4 Hyperparameter tuning | Role 4 – Modelling |
| `scripts/03_selection_validation.py` | 5 Feature selection (incl. climate), 6 Validation | Role 5 – Validation |
| `scripts/04_forecast.py` | 7 Forecast | Role 1 – Lead |
| `dashboard/app.py` | Bonus dashboard | Role 2 / 5 |
| `src/config.py` | Shared settings (horizon, split sizes, paths) | everyone |
| `src/evaluate.py`, `src/modeling.py`, `src/data.py` | Metrics, baselines, model builders | everyone |
| `data/raw/` | Original CSVs (never edited) | |
| `outputs/` | Results tables, `forecast_30_days.csv`, figures | |

## Method in short

- **Pre-processing:** joined sales and climate on date. The climate file has 2025-02-28 twice, so we averaged the two rows. Made the series daily and continuous: days without records = 0 sales (mostly Sun/Mon and holidays). Large orders are kept.
- **Split (time order, no shuffling):** train Jan 2021–Aug 2025 · validation Aug 2025–Jan 2026 (180 days, for tuning) · test Jan–Jul 2026 (180 days, used once).
- **Features:** lags (past sales), rolling 7/28-day mean and std, weekday, cyclical day-of-year and month, German holidays, days until Easter / Ascension (Father's Day), 9 climate variables plus 7-day climate averages.
- **Models:** two baselines (same weekday last year; weekday average of last 8 weeks), Random Forest, and LightGBM with a **Tweedie** loss, which suits many-zeros and rare large orders.
- **Tuning:** grid search over lags × hyperparameters with time-series cross-validation (6 windows of 30 days). Tuning metric = WAPE + error of the 30-day totals, because daily MAE alone rewards models that under-forecast the 30-day amount.
- **Feature selection:** RFECV (recursive feature elimination) on the exogenous features. We also tested the same model with no climate / all climate / selected features.
- **Validation:** backtesting on the hidden test period with refit every 30 days. Metrics: MAE, RMSE, WAPE, 30-day total error. No MAPE, because many days have zero sales.
- **Forecast:** retrained on all data. Future weather = the historical average for each calendar day. The 80% interval comes from bootstrapped out-of-sample errors.

## Results (test period Jan–Jul 2026)

| Model | MAE (bottles/day) | 30-day total error |
| --- | --- | --- |
| LightGBM-Tweedie + climate | 471 | 25% |
| LightGBM-Tweedie, no climate | 474 | 24% |
| Baseline: weekday average last 8 weeks | 516 | 35% |
| Baseline: same weekday last year | 630 | 28% |

- The tuned model beats both baselines.
- **Climate adds almost nothing:** the difference with vs. without climate is not significant (Wilcoxon p ≈ 0.90), and climate features carry about 6% of the SHAP importance. Seasonality, the calendar, and recent sales drive the forecast.
- **Forecast 30 Jul – 28 Aug 2026: ≈ 8,000 bottles** (80% range ≈ 6,200 – 16,000). For comparison, the same period last year sold 8,959 and the previous 30 days sold 15,750 (end of peak season).
- Sales are very lumpy (the top 10% of days = 68% of bottles). Order-level data (customers, promotions) would help more than more weather data.

Numbers may differ slightly after re-running with other library versions.
